---
id: 5c526dbf-9dd7-4c52-98d8-54e00ebddfb6
blueprint: page
title: 'Contact form'
updated_by: ceaa75bd-bc37-4a8b-b0f2-b7af70e58b0e
updated_at: 1698695250
seo_noindex: false
seo_nofollow: false
seo_canonical_type: entry
sitemap_change_frequency: weekly
sitemap_priority: 0.5
page_builder:
  -
    id: QGsYdcyd
    title: 'A contact form'
    text: 'Both the receiver and the owner of the website will receive a styled e-mail. Forms are dynamic, work with conditional logic and use Laravel Precognition for validation and submission.'
    form: contact
    type: form
    enabled: true
---
