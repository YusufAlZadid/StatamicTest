---
id: home
blueprint: page
title: Home
updated_by: c4b9ce82-9489-41b7-a710-a9a1178bcb37
updated_at: 1706713540
seo_noindex: false
seo_nofollow: false
seo_canonical_type: entry
sitemap_change_frequency: weekly
sitemap_priority: 0.5
page_builder:
  -
    id: eFlcYHyl
    title: Features
    type: cards
    enabled: true
    cards:
      -
        id: lly5m22j
        title: 'Contact Form'
        text: 'Fusce vulputate eleifend sapien. Curabitur blandit mollis lacus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'
        label: 'Send a form'
        link_type: entry
        target_blank: false
        entry: 5c526dbf-9dd7-4c52-98d8-54e00ebddfb6
        button_type: inline
        type: card
        enabled: true
        button:
          -
            id: llz6sh4t
            label: 'Send a form'
            link_type: entry
            target_blank: true
            entry: 5c526dbf-9dd7-4c52-98d8-54e00ebddfb6
            button_type: button
      -
        id: lly5mxh7
        title: 'Long Form Content'
        text: 'Quisque malesuada placerat nisl. Nulla sit amet est. Curabitur nisi. Quisque id odio. Pellentesque dapibus hendrerit tortor.'
        label: 'Read an article'
        link_type: entry
        target_blank: false
        entry: 20f6a148-63b8-47a8-9b0e-d57095d78c21
        button_type: inline
        type: card
        enabled: true
        button:
          -
            id: llz6svox
            label: 'Read an article'
            link_type: entry
            target_blank: true
            entry: 20f6a148-63b8-47a8-9b0e-d57095d78c21
            button_type: button
      -
        id: lly5nvk4
        title: '404 Page'
        text: 'Fusce pharetra convallis urna. Nullam quis ante. Donec id justo. Etiam ultricies nisi vel augue. Etiam feugiat lorem non metus.'
        label: 'Climb the docs'
        link_type: url
        target_blank: true
        url: 'https://peak.1902.studio'
        button_type: inline
        type: card
        enabled: true
        button:
          -
            id: llz6t5ao
            label: 'Read the docs'
            link_type: entry
            target_blank: true
            entry: 059d4d8d-fc60-49f8-8823-7da10549e84e
            button_type: button
  -
    id: T5ZZwBfn
    article:
      -
        type: heading
        attrs:
          level: 1
        content:
          -
            type: text
            text: 'Donec venenatis vulputate'
      -
        type: paragraph
        content:
          -
            type: text
            text: 'Test paragraph 2'
      -
        type: paragraph
        content:
          -
            type: text
            text: 'Test Paragraph 3'
    type: article
    enabled: true
---
