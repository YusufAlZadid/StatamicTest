---
id: 2e5a2312-867a-4bcb-ba1a-81e559eb81d7
blueprint: template2
title: 'Donation Page2'
author: ab69dc41-2a22-45f2-a2cc-9bdcfc2513b4
template: campaigns/campaign
updated_by: ab69dc41-2a22-45f2-a2cc-9bdcfc2513b4
updated_at: 1710304525
---
