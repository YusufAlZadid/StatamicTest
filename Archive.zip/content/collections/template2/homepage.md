---
id: 2b2dd989-b84b-4288-a90e-8a0cd1405f90
blueprint: template2
title: Homepage
author: ab69dc41-2a22-45f2-a2cc-9bdcfc2513b4
template: home
updated_by: ab69dc41-2a22-45f2-a2cc-9bdcfc2513b4
updated_at: 1710304490
---
This is the test home page of Template 2