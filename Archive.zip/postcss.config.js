export default {
    plugins: {
        'postcss-import': {},
        tailwindcss: {},
        '@csstools/postcss-oklab-function': { 'preserve': true },
        autoprefixer: {},
    },
};
