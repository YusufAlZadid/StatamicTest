<?php use function Statamic\trans as __; ?>

<div class="card p-0 overflow-hidden">
    <div class="flex justify-between items-center p-4">
        <h2>
            <a class="flex items-center" href="<?php echo e($form->showUrl()); ?>">
                <div class="h-6 w-6 rtl:ml-2 ltr:mr-2 text-gray-800">
                    <?php echo Statamic::svg('icons/light/drawer-file') ?>
                </div>
                <span v-pre><?php echo e($title); ?></span>
            </a>
        </h2>
    </div>
    <div>
        <?php if( ! $submissions): ?>
            <p class="p-4 pt-2 text-sm text-gray-600"><?php echo e(__('This form is awaiting responses')); ?></p>
        <?php else: ?>
            <table class="data-table">
                <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><a href="<?php echo e(cp_route('forms.submissions.show', [$form->handle(), $submission['id']])); ?>"><?php echo e(array_get($submission, $field)); ?></a></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td class="rtl:text-left ltr:text-right">
                            <?php echo e(($submission['date']->diffInDays() <= 14) ? $submission['date']->diffForHumans() : $submission['date']->format($format)); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /Users/alzadidyusuf/Herd/statamictest/vendor/statamic/cms/src/Providers/../../resources/views/forms/widget.blade.php ENDPATH**/ ?>