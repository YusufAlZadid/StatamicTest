<?php use function Statamic\trans as __; ?>


<?php $__env->startSection('title', Statamic::crumb(__('Email'), __('Utilities'))); ?>

<?php $__env->startSection('content'); ?>

    <header class="mb-6">
        <?php echo $__env->make('statamic::partials.breadcrumb', [
            'url' => cp_route('utilities.index'),
            'title' => __('Utilities')
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h1><?php echo e(__('Email')); ?></h1>
    </header>

    <div class="card">
        <form method="POST" action="<?php echo e(cp_route('utilities.email')); ?>">
            <?php echo csrf_field(); ?>

            <div class="flex items-center">
                <input class="input-text rtl:ml-4 ltr:mr-4" type="text" name="email" value="<?php echo e(old('email', $user->email())); ?>" />
                <button type="submit" class="btn-primary"><?php echo e(__('Send Test Email')); ?></button>
            </div>
            <?php if($errors->has('email')): ?>
                <p class="mt-2"><small class="help-block text-red-500"><?php echo e($errors->first('email')); ?></small></p>
            <?php endif; ?>
        </form>
    </div>

    <h2 class="mt-10 mb-2 font-bold text-lg"><?php echo e(__('Configuration')); ?></h2>
    <p class="text-sm text-gray mb-4"><?php echo __('statamic::messages.email_utility_configuration_description', ['path' => config_path('mail.php')]); ?></p>
    <div class="card p-0">
        <table class="data-table">
            <tr>
                <th class="rtl:pr-4 ltr:pl-4 py-2 w-1/4"><?php echo e(__('Default Mailer')); ?></th>
                <td><code><?php echo e(config('mail.default')); ?></code></td>
            </tr>
            <?php if(config('mail.default') == 'smtp'): ?>
            <tr>
                <th class="rtl:pr-4 ltr:pl-4 py-2 w-1/4"><?php echo e(__('Host')); ?></th>
                <td><code><?php echo e(config('mail.mailers.smtp.host')); ?></code></td>
            </tr>
            <tr>
                <th class="rtl:pr-4 ltr:pl-4 py-2 w-1/4"><?php echo e(__('Port')); ?></th>
                <td><code><?php echo e(config('mail.mailers.smtp.port')); ?></code></td>
            </tr>
            <tr>
                <th class="rtl:pr-4 ltr:pl-4 py-2 w-1/4"><?php echo e(__('Encryption')); ?></th>
                <td>
                    <?php if(config('mail.mailers.smtp.encryption')): ?>
                        <code><?php echo e(config('mail.mailers.smtp.encryption')); ?></code>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th class="rtl:pr-4 ltr:pl-4 py-2 w-1/4"><?php echo e(__('Username')); ?></th>
                <td>
                    <?php if(config('mail.mailers.smtp.username')): ?>
                        <code><?php echo e(config('mail.mailers.smtp.username')); ?></code>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th class="rtl:pr-4 ltr:pl-4 py-2 w-1/4"><?php echo e(__('Password')); ?></th>
                <td>
                    <?php if(config('mail.mailers.smtp.password')): ?>
                        <code><?php echo e(config('mail.mailers.smtp.password')); ?></code>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endif; ?>
            <?php if(config('mail.default') == 'sendmail'): ?>
            <tr>
                <th class="rtl:pr-4 ltr:pl-4 py-2 w-1/4"><?php echo e(__('Sendmail')); ?></th>
                <td><code><?php echo e(config('mail.mailers.sendmail.path')); ?></code></td>
            </tr>
            <?php endif; ?>
            <tr>
                <th class="rtl:pr-4 ltr:pl-4 py-2 w-1/4"><?php echo e(__('Default From Address')); ?></th>
                <td>
                    <?php if(config('mail.from.address')): ?>
                        <code><?php echo e(config('mail.from.address')); ?></code>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th class="rtl:pr-4 ltr:pl-4 py-2 w-1/4"><?php echo e(__('Default From Name')); ?></th>
                <td>
                    <?php if(config('mail.from.name')): ?>
                        <code><?php echo e(config('mail.from.name')); ?></code>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th class="rtl:pr-4 ltr:pl-4 py-2 w-1/4"><?php echo e(__('Markdown theme')); ?></th>
                <td>
                    <?php if(config('mail.markdown.theme')): ?>
                        <code><?php echo e(config('mail.markdown.theme')); ?></code>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th class="rtl:pr-4 ltr:pl-4 py-2 w-1/4"><?php echo e(__('Markdown paths')); ?></th>
                <td>
                    <?php $__currentLoopData = config('mail.markdown.paths'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <code><?php echo e($path); ?></code><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('statamic::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alzadidyusuf/Herd/statamictest/vendor/statamic/cms/src/Providers/../../resources/views/utilities/email.blade.php ENDPATH**/ ?>