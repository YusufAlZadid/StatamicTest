// Detect click inside fake header menu(iframe)

// let monitor = setInterval(function(){
//     let elem = document.activeElement;
//     if(elem && elem.tagName == 'IFRAME'){
//         //clearInterval(monitor);
//         elem.blur();
//         console.log('clicked! ');
//         $('#fake-menu-2 iframe').css({
//             'height' : '100%'
//         })
//     }
// }, 100);