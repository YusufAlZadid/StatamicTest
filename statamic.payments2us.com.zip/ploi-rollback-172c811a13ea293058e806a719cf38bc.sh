#!/bin/bash

set -e
# In case of composer:
# composer install --no-interaction --prefer-dist --optimize-autoloader

# In case of Laravel:
# php artisan migrate --force

echo "🚀 Rollback has ran!"