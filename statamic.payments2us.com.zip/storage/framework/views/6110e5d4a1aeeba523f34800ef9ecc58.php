<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>" dir="<?php echo e(Statamic\Facades\Site::selected()->direction()); ?>">
<head>
    <?php echo $__env->make('statamic::partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div id="statamic">

        <?php echo $__env->make('statamic::partials.session-expiry', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('statamic::partials.licensing-alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('statamic::partials.global-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="main"
            class="<?php echo $__env->yieldContent('content-class'); ?>"
            :class="{
                'nav-closed': ! navOpen,
                'nav-mobile-open': mobileNavOpen,
                'showing-license-banner': showBanner
            }"
        >
            <?php echo $__env->make('statamic::partials.nav-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('statamic::partials.nav-mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="workspace">
                <div class="page-wrapper" :class="wrapperClass">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>

        </div>

        <component
            v-for="component in appendedComponents"
            :key="component.id"
            :is="component.name"
            v-bind="component.props"
            v-on="component.events"
        ></component>

        <keyboard-shortcuts-modal></keyboard-shortcuts-modal>

        <portal-targets></portal-targets>

    </div>

    <?php echo $__env->make('statamic::partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH /home/ploi/statamic.payments2us.com/vendor/statamic/cms/src/Providers/../../resources/views/layout.blade.php ENDPATH**/ ?>