<?php

return [

    'pro' => true,

    'addons' => [
        //
    ],

];
