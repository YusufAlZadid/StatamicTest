<?php return array (
  'ajthinking/archetype' => 
  array (
    'dont-discover' => 
    array (
    ),
    'providers' => 
    array (
      0 => 'Archetype\\ServiceProvider',
    ),
  ),
  'barryvdh/laravel-debugbar' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Debugbar\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Debugbar' => 'Barryvdh\\Debugbar\\Facades\\Debugbar',
    ),
  ),
  'duncanmcclean/static-cache-manager' => 
  array (
    'providers' => 
    array (
      0 => 'DuncanMcClean\\StaticCacheManager\\ServiceProvider',
    ),
  ),
  'goldnead/statamic-collapse-fieldtype' => 
  array (
    'providers' => 
    array (
      0 => 'Goldnead\\CollapseFieldtype\\ServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'rebing/graphql-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Rebing\\GraphQL\\GraphQLServiceProvider',
    ),
    'aliases' => 
    array (
      'GraphQL' => 'Rebing\\GraphQL\\Support\\Facades\\GraphQL',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
  ),
  'statamic/cms' => 
  array (
    'providers' => 
    array (
      0 => 'Statamic\\Providers\\StatamicServiceProvider',
    ),
    'aliases' => 
    array (
      'Statamic' => 'Statamic\\Statamic',
    ),
  ),
  'studio1902/statamic-peak-browser-appearance' => 
  array (
    'providers' => 
    array (
      0 => 'Studio1902\\PeakBrowserAppearance\\ServiceProvider',
    ),
  ),
  'studio1902/statamic-peak-commands' => 
  array (
    'providers' => 
    array (
      0 => 'Studio1902\\PeakCommands\\ServiceProvider',
    ),
  ),
  'studio1902/statamic-peak-seo' => 
  array (
    'providers' => 
    array (
      0 => 'Studio1902\\PeakSeo\\ServiceProvider',
    ),
  ),
  'studio1902/statamic-peak-tools' => 
  array (
    'providers' => 
    array (
      0 => 'Studio1902\\PeakTools\\ServiceProvider',
    ),
  ),
  'wilderborn/partyline' => 
  array (
    'providers' => 
    array (
      0 => 'Wilderborn\\Partyline\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Partyline' => 'Wilderborn\\Partyline\\Facade',
    ),
  ),
);