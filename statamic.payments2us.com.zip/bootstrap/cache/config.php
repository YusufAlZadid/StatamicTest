<?php return array (
  'app' => 
  array (
    'name' => 'AsylumSeekers',
    'env' => 'local',
    'debug' => false,
    'url' => 'http://statamic.asylumseekerscentre.local',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:UNIVprawYxWHVwdsMgGBQG7S8l3fHqgQ6KwSvGvJ89E=',
    'cipher' => 'AES-256-CBC',
    'maintenance' => 
    array (
      'driver' => 'file',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      15 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      16 => 'Illuminate\\Queue\\QueueServiceProvider',
      17 => 'Illuminate\\Redis\\RedisServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'App\\Providers\\AppServiceProvider',
      23 => 'App\\Providers\\AuthServiceProvider',
      24 => 'App\\Providers\\EventServiceProvider',
      25 => 'App\\Providers\\RouteServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Number' => 'Illuminate\\Support\\Number',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'resets',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'sanctum' => 
      array (
        'driver' => 'sanctum',
        'provider' => NULL,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'statamic',
      ),
    ),
    'passwords' => 
    array (
      'resets' => 
      array (
        'provider' => 'users',
        'table' => 'password_reset_tokens',
        'expire' => 60,
        'throttle' => 60,
      ),
      'activations' => 
      array (
        'provider' => 'users',
        'table' => 'password_activation_tokens',
        'expire' => 4320,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'cluster' => NULL,
          'host' => 'api-mt1.pusher.com',
          'port' => 443,
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'statamic',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
        'lock_connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/home/ploi/statamic.payments2us.com/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => NULL,
        'secret' => NULL,
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
      'statamic' => 
      array (
        'driver' => 'statamic',
      ),
    ),
    'prefix' => 'asylumseekers_cache_',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => '/home/ploi/statamic.payments2us.com/database/database.sqlite',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'forge',
        'username' => 'forge',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '5432',
        'database' => 'forge',
        'username' => 'forge',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => 'localhost',
        'port' => '1433',
        'database' => 'forge',
        'username' => 'forge',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'asylumseekers_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/home/ploi/statamic.payments2us.com/storage/app',
        'throw' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/home/ploi/statamic.payments2us.com/storage/app/public',
        'url' => 'http://statamic.asylumseekerscentre.local/storage',
        'visibility' => 'public',
        'throw' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
      ),
      'images' => 
      array (
        'driver' => 'local',
        'root' => '/home/ploi/statamic.payments2us.com/public/images',
        'url' => '/images',
        'visibility' => 'public',
      ),
      'favicons' => 
      array (
        'driver' => 'local',
        'root' => '/home/ploi/statamic.payments2us.com/public/favicons',
        'url' => '/favicons',
        'visibility' => 'public',
      ),
      'files' => 
      array (
        'driver' => 'local',
        'root' => '/home/ploi/statamic.payments2us.com/public/files',
        'url' => '/files',
        'visibility' => 'public',
      ),
      'social_images' => 
      array (
        'driver' => 'local',
        'root' => '/home/ploi/statamic.payments2us.com/public/social_images',
        'url' => '/social_images',
        'visibility' => 'public',
      ),
      'assets' => 
      array (
        'driver' => 'local',
        'root' => '/home/ploi/statamic.payments2us.com/public/assets',
        'url' => '/assets',
        'visibility' => 'public',
      ),
    ),
    'links' => 
    array (
      '/home/ploi/statamic.payments2us.com/public/storage' => '/home/ploi/statamic.payments2us.com/storage/app/public',
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => 'null',
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/home/ploi/statamic.payments2us.com/storage/logs/laravel.log',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/home/ploi/statamic.payments2us.com/storage/logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
        'replace_placeholders' => true,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
        'replace_placeholders' => true,
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
        'facility' => 8,
        'replace_placeholders' => true,
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => '/home/ploi/statamic.payments2us.com/storage/logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'smtp.postmarkapp.com',
        'port' => '587',
        'encryption' => 'tls',
        'username' => '',
        'password' => '',
        'timeout' => NULL,
        'local_domain' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
    ),
    'from' => 
    array (
      'address' => '',
      'name' => 'AsylumSeekers',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/home/ploi/statamic.payments2us.com/resources/views/vendor/mail',
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => NULL,
        'secret' => NULL,
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'batching' => 
    array (
      'database' => 'mysql',
      'table' => 'job_batches',
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'sanctum' => 
  array (
    'stateful' => 
    array (
      0 => 'localhost',
      1 => 'localhost:3000',
      2 => '127.0.0.1',
      3 => '127.0.0.1:8000',
      4 => '::1',
      5 => 'statamic.asylumseekerscentre.local',
    ),
    'guard' => 
    array (
      0 => 'web',
    ),
    'expiration' => NULL,
    'token_prefix' => '',
    'middleware' => 
    array (
      'verify_csrf_token' => 'App\\Http\\Middleware\\VerifyCsrfToken',
      'encrypt_cookies' => 'App\\Http\\Middleware\\EncryptCookies',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
      'scheme' => 'https',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/home/ploi/statamic.payments2us.com/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'asylumseekers_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'statamic' => 
  array (
    'antlers' => 
    array (
      'version' => 'runtime',
      'guardedVariables' => 
      array (
        0 => 'config.app.key',
      ),
      'guardedTags' => 
      array (
      ),
      'guardedModifiers' => 
      array (
      ),
    ),
    'api' => 
    array (
      'enabled' => false,
      'resources' => 
      array (
        'collections' => false,
        'navs' => false,
        'taxonomies' => false,
        'assets' => false,
        'globals' => false,
        'forms' => false,
        'users' => false,
      ),
      'route' => 'api',
      'middleware' => 'api',
      'pagination_size' => 50,
      'cache' => 
      array (
        'expiry' => 60,
      ),
      'excluded_keys' => 
      array (
      ),
    ),
    'assets' => 
    array (
      'image_manipulation' => 
      array (
        'route' => 'img',
        'secure' => true,
        'driver' => 'imagick',
        'additional_extensions' => 
        array (
        ),
        'cache' => false,
        'cache_path' => '/home/ploi/statamic.payments2us.com/public/img',
        'defaults' => 
        array (
        ),
        'presets' => 
        array (
          'replacement' => 
          array (
            'w' => 4500,
            'fit' => 'max',
          ),
        ),
        'generate_presets_on_upload' => true,
        'append_original_filename' => true,
      ),
      'auto_crop' => true,
      'thumbnails' => 
      array (
        'max_width' => 10000,
        'max_height' => 10000,
      ),
      'google_docs_viewer' => false,
      'cache_meta' => true,
      'focal_point_editor' => true,
      'lowercase' => true,
      'additional_uploadable_extensions' => 
      array (
      ),
    ),
    'autosave' => 
    array (
      'enabled' => false,
      'interval' => 5000,
    ),
    'cp' => 
    array (
      'enabled' => true,
      'route' => 'cp',
      'start_page' => 'dashboard',
      'widgets' => 
      array (
        0 => 
        array (
          'type' => 'images_missing_alt',
          'container' => 'images',
          'limit' => 5,
          'width' => 50,
        ),
        1 => 
        array (
          'type' => 'collection',
          'collection' => 'pages',
          'width' => 50,
        ),
        2 => 
        array (
          'type' => 'form',
          'form' => 'contact',
          'fields' => 
          array (
            0 => 'name',
            1 => 'email',
          ),
          'limit' => '5',
          'width' => 100,
        ),
      ),
      'date_format' => 'Y-m-d',
      'pagination_size' => 50,
      'pagination_size_options' => 
      array (
        0 => 10,
        1 => 25,
        2 => 50,
        3 => 100,
        4 => 500,
      ),
      'link_to_docs' => true,
      'support_url' => 'https://statamic.com/support',
      'theme' => 'business',
      'custom_cms_name' => 'Statamic',
      'custom_logo_url' => 
      array (
        'nav' => NULL,
        'outside' => '/visuals/client-logo.svg',
      ),
      'custom_favicon_url' => NULL,
      'custom_css_url' => NULL,
      'thumbnail_presets' => 
      array (
      ),
    ),
    'editions' => 
    array (
      'pro' => true,
      'addons' => 
      array (
      ),
    ),
    'forms' => 
    array (
      'forms' => '/home/ploi/statamic.payments2us.com/resources/forms',
      'submissions' => '/home/ploi/statamic.payments2us.com/storage/forms',
      'email_view_folder' => NULL,
      'send_email_job' => 'Statamic\\Forms\\SendEmail',
      'exporters' => 
      array (
        'csv' => 
        array (
          'class' => 'Statamic\\Forms\\Exporters\\CsvExporter',
        ),
        'json' => 
        array (
          'class' => 'Statamic\\Forms\\Exporters\\JsonExporter',
        ),
      ),
      'csv_delimiter' => ',',
      'csv_headers' => 'display',
    ),
    'git' => 
    array (
      'enabled' => true,
      'automatic' => true,
      'queue_connection' => NULL,
      'dispatch_delay' => '2',
      'use_authenticated' => false,
      'user' => 
      array (
        'name' => 'randzgonz02',
        'email' => 'randzgonz02@gmail.com',
      ),
      'paths' => 
      array (
        0 => '/home/ploi/statamic.payments2us.com/content',
        1 => '/home/ploi/statamic.payments2us.com/users',
        2 => '/home/ploi/statamic.payments2us.com/resources/blueprints',
        3 => '/home/ploi/statamic.payments2us.com/resources/fieldsets',
        4 => '/home/ploi/statamic.payments2us.com/resources/forms',
        5 => '/home/ploi/statamic.payments2us.com/resources/users',
        6 => '/home/ploi/statamic.payments2us.com/resources/preferences.yaml',
        7 => '/home/ploi/statamic.payments2us.com/storage/forms',
        8 => '/home/ploi/statamic.payments2us.com/public/images',
        9 => '/home/ploi/statamic.payments2us.com/public/favicons',
        10 => '/home/ploi/statamic.payments2us.com/public/files',
        11 => '/home/ploi/statamic.payments2us.com/public/social_images',
      ),
      'binary' => 'git',
      'commands' => 
      array (
        0 => 'git add {{ paths }}',
        1 => 'git -c "user.name={{ name }}" -c "user.email={{ email }}" commit -m "{{ message }} [BOT]"',
      ),
      'push' => true,
      'ignored_events' => 
      array (
      ),
      'locale' => NULL,
    ),
    'graphql' => 
    array (
      'enabled' => false,
      'resources' => 
      array (
        'collections' => false,
        'navs' => false,
        'taxonomies' => false,
        'assets' => false,
        'globals' => false,
        'forms' => false,
        'sites' => false,
        'users' => false,
      ),
      'queries' => 
      array (
      ),
      'middleware' => 
      array (
      ),
      'cache' => 
      array (
        'expiry' => 60,
      ),
    ),
    'live_preview' => 
    array (
      'devices' => 
      array (
        'xs' => 
        array (
          'width' => 375,
          'height' => 667,
        ),
        'sm' => 
        array (
          'width' => 640,
          'height' => 786,
        ),
        'md' => 
        array (
          'width' => 768,
          'height' => 1024,
        ),
        'lg' => 
        array (
          'width' => 1024,
          'height' => 800,
        ),
        'xl' => 
        array (
          'width' => 1280,
          'height' => 900,
        ),
        '2xl' => 
        array (
          'width' => 1440,
          'height' => 900,
        ),
      ),
      'inputs' => 
      array (
      ),
    ),
    'markdown' => 
    array (
      'configs' => 
      array (
        'default' => 
        array (
        ),
      ),
    ),
    'oauth' => 
    array (
      'enabled' => false,
      'email_login_enabled' => true,
      'providers' => 
      array (
      ),
      'routes' => 
      array (
        'login' => 'oauth/{provider}',
        'callback' => 'oauth/{provider}/callback',
      ),
      'remember_me' => true,
    ),
    'protect' => 
    array (
      'default' => NULL,
      'schemes' => 
      array (
        'ip_address' => 
        array (
          'driver' => 'ip_address',
          'allowed' => 
          array (
            0 => '127.0.0.1',
          ),
        ),
        'logged_in' => 
        array (
          'driver' => 'auth',
          'login_url' => '/login',
          'append_redirect' => true,
        ),
        'password' => 
        array (
          'driver' => 'password',
          'allowed' => 
          array (
            0 => 'secret',
          ),
          'form_url' => NULL,
        ),
      ),
    ),
    'revisions' => 
    array (
      'enabled' => true,
      'path' => '/home/ploi/statamic.payments2us.com/content/revisions',
    ),
    'routes' => 
    array (
      'enabled' => true,
      'bindings' => false,
      'action' => '!',
      'middleware' => 'web',
    ),
    'search' => 
    array (
      'default' => 'default',
      'indexes' => 
      array (
        'default' => 
        array (
          'driver' => 'local',
          'searchables' => 'all',
          'fields' => 
          array (
            0 => 'title',
            1 => 'page_builder',
          ),
        ),
      ),
      'drivers' => 
      array (
        'local' => 
        array (
          'path' => '/home/ploi/statamic.payments2us.com/storage/statamic/search',
        ),
        'algolia' => 
        array (
          'credentials' => 
          array (
            'id' => '',
            'secret' => '',
          ),
        ),
      ),
      'defaults' => 
      array (
        'fields' => 
        array (
          0 => 'title',
        ),
      ),
    ),
    'sites' => 
    array (
      'sites' => 
      array (
        'default' => 
        array (
          'name' => 'AsylumSeekers',
          'locale' => 'en_US',
          'url' => '/',
        ),
      ),
    ),
    'stache' => 
    array (
      'watcher' => true,
      'stores' => 
      array (
        'taxonomies' => 
        array (
          'class' => 'Statamic\\Stache\\Stores\\TaxonomiesStore',
          'directory' => '/home/ploi/statamic.payments2us.com/content/taxonomies',
        ),
        'terms' => 
        array (
          'class' => 'Statamic\\Stache\\Stores\\TermsStore',
          'directory' => '/home/ploi/statamic.payments2us.com/content/taxonomies',
        ),
        'collections' => 
        array (
          'class' => 'Statamic\\Stache\\Stores\\CollectionsStore',
          'directory' => '/home/ploi/statamic.payments2us.com/content/collections',
        ),
        'entries' => 
        array (
          'class' => 'Statamic\\Stache\\Stores\\EntriesStore',
          'directory' => '/home/ploi/statamic.payments2us.com/content/collections',
        ),
        'navigation' => 
        array (
          'class' => 'Statamic\\Stache\\Stores\\NavigationStore',
          'directory' => '/home/ploi/statamic.payments2us.com/content/navigation',
        ),
        'collection-trees' => 
        array (
          'class' => 'Statamic\\Stache\\Stores\\CollectionTreeStore',
          'directory' => '/home/ploi/statamic.payments2us.com/content/trees/collections',
        ),
        'nav-trees' => 
        array (
          'class' => 'Statamic\\Stache\\Stores\\NavTreeStore',
          'directory' => '/home/ploi/statamic.payments2us.com/content/trees/navigation',
        ),
        'globals' => 
        array (
          'class' => 'Statamic\\Stache\\Stores\\GlobalsStore',
          'directory' => '/home/ploi/statamic.payments2us.com/content/globals',
        ),
        'asset-containers' => 
        array (
          'class' => 'Statamic\\Stache\\Stores\\AssetContainersStore',
          'directory' => '/home/ploi/statamic.payments2us.com/content/assets',
        ),
        'assets' => 
        array (
          'class' => 'Statamic\\Stache\\Stores\\AssetsStore',
        ),
        'users' => 
        array (
          'class' => 'Statamic\\Stache\\Stores\\UsersStore',
          'directory' => '/home/ploi/statamic.payments2us.com/users',
        ),
      ),
      'indexes' => 
      array (
      ),
      'lock' => 
      array (
        'enabled' => true,
        'timeout' => 30,
      ),
    ),
    'static_caching' => 
    array (
      'strategy' => NULL,
      'strategies' => 
      array (
        'half' => 
        array (
          'driver' => 'application',
          'expiry' => NULL,
        ),
        'full' => 
        array (
          'driver' => 'file',
          'path' => '/home/ploi/statamic.payments2us.com/public/static',
          'lock_hold_length' => 0,
          'warm_concurrency' => 10,
        ),
      ),
      'exclude' => 
      array (
        0 => '/site.webmanifest',
        1 => '/sitemap.xml',
        2 => '/sitemaps.xml',
      ),
      'invalidation' => 
      array (
        'class' => NULL,
        'rules' => 'all',
      ),
      'ignore_query_strings' => false,
      'replacers' => 
      array (
        0 => 'Statamic\\StaticCaching\\Replacers\\CsrfTokenReplacer',
        1 => 'Statamic\\StaticCaching\\Replacers\\NoCacheReplacer',
      ),
      'warm_queue' => NULL,
    ),
    'system' => 
    array (
      'license_key' => '',
      'addons_path' => '/home/ploi/statamic.payments2us.com/addons',
      'send_powered_by_header' => true,
      'date_format' => 'F jS, Y',
      'charset' => 'UTF-8',
      'track_last_update' => true,
      'cache_tags_enabled' => false,
      'php_memory_limit' => '-1',
      'php_max_execution_time' => '-1',
      'ajax_timeout' => '600000',
      'pcre_backtrack_limit' => '-1',
      'debugbar' => 
      array (
        'pretty_print_variables' => true,
      ),
      'ascii_replace_extra_symbols' => false,
      'update_references' => true,
      'row_id_handle' => 'id',
    ),
    'users' => 
    array (
      'repository' => 'file',
      'repositories' => 
      array (
        'file' => 
        array (
          'driver' => 'file',
          'paths' => 
          array (
            'users' => '/home/ploi/statamic.payments2us.com/users',
            'roles' => '/home/ploi/statamic.payments2us.com/resources/users/roles.yaml',
            'groups' => '/home/ploi/statamic.payments2us.com/resources/users/groups.yaml',
          ),
        ),
        'eloquent' => 
        array (
          'driver' => 'eloquent',
        ),
      ),
      'avatars' => 'initials',
      'new_user_roles' => 
      array (
      ),
      'new_user_groups' => 
      array (
      ),
      'registration_form_honeypot_field' => NULL,
      'wizard_invitation' => true,
      'passwords' => 
      array (
        'resets' => 'resets',
        'activations' => 'activations',
      ),
      'database' => 'mysql',
      'tables' => 
      array (
        'users' => 'users',
        'role_user' => 'role_user',
        'group_user' => 'group_user',
      ),
      'guards' => 
      array (
        'cp' => 'web',
        'web' => 'web',
      ),
      'impersonate' => 
      array (
        'enabled' => true,
        'redirect' => NULL,
      ),
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/home/ploi/statamic.payments2us.com/resources/views',
    ),
    'compiled' => '/home/ploi/statamic.payments2us.com/storage/framework/views',
  ),
  'archetype' => 
  array (
    'roots' => 
    array (
      'input' => 
      array (
        'driver' => 'local',
        'root' => '/home/ploi/statamic.payments2us.com',
      ),
      'output' => 
      array (
        'driver' => 'local',
        'root' => '/home/ploi/statamic.payments2us.com',
      ),
      'debug' => 
      array (
        'driver' => 'local',
        'root' => '/home/ploi/statamic.payments2us.com/storage/archetype/debug',
      ),
    ),
    'ignored_paths' => 
    array (
      0 => 'node_modules',
      1 => 'vendor',
      2 => '_ide_helper.php',
      3 => '.git',
    ),
    'snippets_path' => 'resources/snippets',
    'locations' => 
    array (
      'namespace_map' => 
      array (
        'app' => 'App',
      ),
      'app_path' => 'app',
      'app_namespace' => 'App',
      'file_root' => '',
      'class_root' => '',
      'commands_root' => 'app/HTTP/Controllers',
      'controllers_root' => 'app/HTTP/Controllers',
      'factories_root' => 'database/factories',
      'migrations_root' => 'database/migrations',
      'models_root' => 'app/Models',
    ),
  ),
  'debugbar' => 
  array (
    'enabled' => false,
    'except' => 
    array (
      0 => 'telescope*',
      1 => 'horizon*',
    ),
    'storage' => 
    array (
      'enabled' => true,
      'open' => false,
      'driver' => 'file',
      'path' => '/home/ploi/statamic.payments2us.com/storage/debugbar',
      'connection' => NULL,
      'provider' => '',
      'hostname' => '127.0.0.1',
      'port' => 2304,
    ),
    'editor' => 'phpstorm',
    'remote_sites_path' => NULL,
    'local_sites_path' => NULL,
    'include_vendors' => true,
    'capture_ajax' => true,
    'add_ajax_timing' => false,
    'ajax_handler_auto_show' => true,
    'error_handler' => false,
    'clockwork' => false,
    'collectors' => 
    array (
      'phpinfo' => true,
      'messages' => true,
      'time' => true,
      'memory' => true,
      'exceptions' => true,
      'log' => true,
      'db' => true,
      'views' => true,
      'route' => true,
      'auth' => false,
      'gate' => true,
      'session' => true,
      'symfony_request' => true,
      'mail' => true,
      'laravel' => false,
      'events' => false,
      'default_request' => false,
      'logs' => false,
      'files' => false,
      'config' => false,
      'cache' => false,
      'models' => true,
      'livewire' => true,
      'jobs' => false,
    ),
    'options' => 
    array (
      'time' => 
      array (
        'memory_usage' => false,
      ),
      'messages' => 
      array (
        'trace' => true,
      ),
      'memory' => 
      array (
        'reset_peak' => false,
        'with_baseline' => false,
        'precision' => 0,
      ),
      'auth' => 
      array (
        'show_name' => true,
      ),
      'db' => 
      array (
        'with_params' => true,
        'backtrace' => true,
        'backtrace_exclude_paths' => 
        array (
        ),
        'timeline' => false,
        'duration_background' => true,
        'explain' => 
        array (
          'enabled' => false,
          'types' => 
          array (
            0 => 'SELECT',
          ),
        ),
        'hints' => false,
        'show_copy' => false,
        'slow_threshold' => false,
        'memory_usage' => false,
        'soft_limit' => 100,
        'hard_limit' => 500,
      ),
      'mail' => 
      array (
        'timeline' => false,
        'full_log' => false,
      ),
      'views' => 
      array (
        'timeline' => false,
        'data' => false,
        'group' => 50,
        'exclude_paths' => 
        array (
          0 => 'vendor/filament',
        ),
      ),
      'route' => 
      array (
        'label' => true,
      ),
      'session' => 
      array (
        'hiddens' => 
        array (
        ),
      ),
      'symfony_request' => 
      array (
        'hiddens' => 
        array (
        ),
      ),
      'events' => 
      array (
        'data' => false,
      ),
      'logs' => 
      array (
        'file' => NULL,
      ),
      'cache' => 
      array (
        'values' => true,
      ),
    ),
    'inject' => true,
    'route_prefix' => '_debugbar',
    'route_middleware' => 
    array (
    ),
    'route_domain' => NULL,
    'theme' => 'dark',
    'debug_backtrace_limit' => 50,
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'flare' => 
  array (
    'key' => NULL,
    'flare_middleware' => 
    array (
      0 => 'Spatie\\FlareClient\\FlareMiddleware\\RemoveRequestIp',
      1 => 'Spatie\\FlareClient\\FlareMiddleware\\AddGitInformation',
      2 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddNotifierName',
      3 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddEnvironmentInformation',
      4 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddExceptionInformation',
      5 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddDumps',
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddLogs' => 
      array (
        'maximum_number_of_collected_logs' => 200,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddQueries' => 
      array (
        'maximum_number_of_collected_queries' => 200,
        'report_query_bindings' => true,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddJobs' => 
      array (
        'max_chained_job_reporting_depth' => 5,
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestBodyFields' => 
      array (
        'censor_fields' => 
        array (
          0 => 'password',
          1 => 'password_confirmation',
        ),
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestHeaders' => 
      array (
        'headers' => 
        array (
          0 => 'API-KEY',
          1 => 'Authorization',
          2 => 'Cookie',
          3 => 'Set-Cookie',
          4 => 'X-CSRF-TOKEN',
          5 => 'X-XSRF-TOKEN',
        ),
      ),
    ),
    'send_logs_as_events' => true,
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'auto',
    'enable_share_button' => true,
    'register_commands' => false,
    'solution_providers' => 
    array (
      0 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\BadMethodCallSolutionProvider',
      1 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\MergeConflictSolutionProvider',
      2 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\UndefinedPropertySolutionProvider',
      3 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\IncorrectValetDbCredentialsSolutionProvider',
      4 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingAppKeySolutionProvider',
      5 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\DefaultDbNameSolutionProvider',
      6 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\TableNotFoundSolutionProvider',
      7 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingImportSolutionProvider',
      8 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\InvalidRouteActionSolutionProvider',
      9 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\ViewNotFoundSolutionProvider',
      10 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\RunningLaravelDuskInProductionProvider',
      11 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingColumnSolutionProvider',
      12 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownValidationSolutionProvider',
      13 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingMixManifestSolutionProvider',
      14 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingViteManifestSolutionProvider',
      15 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingLivewireComponentSolutionProvider',
      16 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UndefinedViewVariableSolutionProvider',
      17 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\GenericLaravelExceptionSolutionProvider',
      18 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\OpenAiSolutionProvider',
      19 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\SailNetworkSolutionProvider',
    ),
    'ignored_solution_providers' => 
    array (
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '/home/ploi/statamic.payments2us.com',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
    'settings_file_path' => '',
    'recorders' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\Recorders\\DumpRecorder\\DumpRecorder',
      1 => 'Spatie\\LaravelIgnition\\Recorders\\JobRecorder\\JobRecorder',
      2 => 'Spatie\\LaravelIgnition\\Recorders\\LogRecorder\\LogRecorder',
      3 => 'Spatie\\LaravelIgnition\\Recorders\\QueryRecorder\\QueryRecorder',
    ),
    'open_ai_key' => NULL,
    'with_stack_frame_arguments' => true,
    'argument_reducers' => 
    array (
      0 => 'Spatie\\Backtrace\\Arguments\\Reducers\\BaseTypeArgumentReducer',
      1 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ArrayArgumentReducer',
      2 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StdClassArgumentReducer',
      3 => 'Spatie\\Backtrace\\Arguments\\Reducers\\EnumArgumentReducer',
      4 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ClosureArgumentReducer',
      5 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeArgumentReducer',
      6 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeZoneArgumentReducer',
      7 => 'Spatie\\Backtrace\\Arguments\\Reducers\\SymphonyRequestArgumentReducer',
      8 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\ModelArgumentReducer',
      9 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\CollectionArgumentReducer',
      10 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StringableArgumentReducer',
    ),
  ),
  'graphql' => 
  array (
    'route' => false,
    'default_schema' => 'default',
    'batching' => 
    array (
      'enable' => true,
    ),
    'schemas' => 
    array (
      'default' => 'Statamic\\GraphQL\\DefaultSchema',
    ),
    'types' => 
    array (
    ),
    'lazyload_types' => true,
    'error_formatter' => 
    array (
      0 => 'Rebing\\GraphQL\\GraphQL',
      1 => 'formatError',
    ),
    'errors_handler' => 
    array (
      0 => 'Rebing\\GraphQL\\GraphQL',
      1 => 'handleErrors',
    ),
    'security' => 
    array (
      'query_max_complexity' => NULL,
      'query_max_depth' => NULL,
      'disable_introspection' => false,
    ),
    'pagination_type' => 'Rebing\\GraphQL\\Support\\PaginationType',
    'simple_pagination_type' => 'Rebing\\GraphQL\\Support\\SimplePaginationType',
    'graphiql' => 
    array (
      'display' => false,
    ),
    'defaultFieldResolver' => NULL,
    'headers' => 
    array (
    ),
    'json_encoding_options' => 0,
    'apq' => 
    array (
      'enable' => false,
      'cache_driver' => 'statamic',
      'cache_prefix' => 'asylumseekers_cache_:graphql.apq',
      'cache_ttl' => 300,
    ),
    'execution_middleware' => 
    array (
      0 => 'Rebing\\GraphQL\\Support\\ExecutionMiddleware\\ValidateOperationParamsMiddleware',
      1 => 'Rebing\\GraphQL\\Support\\ExecutionMiddleware\\AutomaticPersistedQueriesMiddleware',
      2 => 'Rebing\\GraphQL\\Support\\ExecutionMiddleware\\AddAuthUserContextValueMiddleware',
    ),
  ),
  'static-cache-manager' => 
  array (
    'defaults' => 
    array (
      'paths' => 
      array (
      ),
    ),
  ),
  'statamic-peak-seo' => 
  array (
    'social_image' => 
    array (
      'node_binary' => NULL,
      'npm_binary' => NULL,
      'queue_name' => 'default',
    ),
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
